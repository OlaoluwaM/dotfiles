---
id: "4145e350-7de7-11ed-bfaf-21ae102b1f0a"
title: "Message to Ciara"
source: "https://www.linkedin.com/feed/"
created_time: "2022-12-17T08:46:10.437Z"
---
Currently, I'd like to try to bring that tuition bill down as much possible by asking them for more aid money and by prodding their office for scholarships 🙂.